import re

def is_valid_proxy(line):
    """Memeriksa apakah baris sesuai dengan format IP:PORT"""
    pattern = re.compile(r'^(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}):(\d{1,5})$')
    return pattern.match(line)

def format_proxy_file(file_path):
    """Membersihkan isi file proxy.txt dengan hanya menghapus baris yang tidak sesuai format"""
    valid_proxies = []
    
    with open(file_path, 'r', encoding='utf-8') as file:
        lines = file.readlines()
    
    total_lines = len(lines)
    for index, line in enumerate(lines):
        line = line.strip()
        if is_valid_proxy(line):
            valid_proxies.append(line)
        
        print(f"Memeriksa: {index + 1}/{total_lines} baris", end='\r')
    
    with open(file_path, 'w', encoding='utf-8') as file:
        file.write('\n'.join(valid_proxies) + '\n')
    
    print(f"\nSelesai! {len(valid_proxies)} proxy valid dipertahankan, sisanya dihapus.")

# Jalankan fungsi dengan file proxy.txt
format_proxy_file("proxy.txt")
