import random
import requests
from bs4 import BeautifulSoup
import concurrent.futures  # Untuk multithreading

# URL sumber data User-Agent terbaru
SOURCE_URL = "https://www.useragentstring.com/pages/useragentstring.php?name=All"
OUTPUT_FILE = "user-agent-generator.txt"

def fetch_page(url):
    """Ambil data halaman web secara langsung."""
    try:
        response = requests.get(url, timeout=10)  # Tambahkan timeout
        response.raise_for_status()
        return response.content
    except Exception as e:
        print(f"Error fetching {url}: {e}")
        return None

def parse_user_agents(html):
    """Ekstrak User-Agent dari HTML."""
    try:
        soup = BeautifulSoup(html, "html.parser")
        user_agents = [tag.text for tag in soup.find_all("li")]
        return user_agents
    except Exception as e:
        print(f"Error parsing HTML: {e}")
        return []

def scrape_user_agents():
    """Scrape User-Agent dari website dan kembalikan semua data."""
    print("Mengambil data User-Agent...")
    html = fetch_page(SOURCE_URL)
    if html:
        return parse_user_agents(html)
    else:
        return []

def save_to_file(data, file_path):
    """Simpan data ke file teks."""
    try:
        with open(file_path, "w") as file:
            file.write("\n".join(data))
        print(f"User-Agent berhasil disimpan di {file_path}")
    except Exception as e:
        print(f"Error saat menyimpan ke file: {e}")

def generate_user_agents(count=1000):
    """
    Menghasilkan User-Agent secara acak.
    - Ambil data dari scraping (jika belum ada di cache).
    - Pilih acak sejumlah `count` dari data yang diambil.
    """
    print("Mengambil User-Agent...")
    user_agents = scrape_user_agents()

    if not user_agents:
        print("Gagal mengambil data User-Agent.")
        return []

    # Pilih User-Agent secara acak
    selected_user_agents = random.sample(user_agents, min(count, len(user_agents)))

    # Simpan ke file
    save_to_file(selected_user_agents, OUTPUT_FILE)

    return selected_user_agents

if __name__ == "__main__":
    jumlah = int(input("Berapa banyak User-Agent yang ingin dihasilkan? "))
    hasil = generate_user_agents(jumlah)

    print("\nUser-Agent yang dihasilkan:")
    for ua in hasil[:10]:  # Cetak 10 User-Agent pertama
        print(ua)
