import random

# Creator @Mrcyberteam
with open('proxyUrls.txt', 'r') as file:
    lines = file.readlines()

lines = [line.strip() for line in lines]

random.shuffle(lines)

with open('proxyUrls.txt', 'w') as file:
    for line in lines:
        file.write(line + '\n')

print("Isi file telah diacak per baris.")
