const axios = require("axios");
const fs = require("fs");
const path = require("path");

const proxyFilePath = "proxyUrls.txt";
const outputFile = "proxy.txt";

if (fs.existsSync(outputFile)) {
    fs.unlinkSync(outputFile);
    console.log("SCRAPPING FUCK PROXY");
}

// Read URLs from the text file
const proxyUrls = fs.readFileSync(proxyFilePath, 'utf8').split('\n').filter(Boolean);

const downloadAndSaveProxies = async (url, outputFile) => {
    try {
        const response = await axios.get(url);
        if (response.status === 200) {
            let dataArray = response.data.split("\n");
            for (let d of dataArray){
                fs.appendFileSync(outputFile, 
                    d.replace("http://", "")
                    .replace("https://", "")
                    .replace("socks4://","")
                    .replace(" ","")
                    .replace("error","")
                    .replace("code","")
                    .replace("socks5://","")
                    .replace(":Indonesia","")
                    .replace(":UnitedStates","")
                    .replace(":Canada","")
                    .replace(":Lithuania","")
                    .replace(":Brazil","")
                    .replace(":Bulgaria","")
                    .replace(":Bangladesh","")
                    .replace(":Singapore","")
                    .replace(":TheNetherlands","")
                    .replace(":France","")
                    .replace(":Spain","")
                    .replace(":Germany","")
                    .replace(":Sweden","")
                    .replace(":Ukraine","")
                    .replace(":India","")
                    .replace(":Vietnam","")
                    .replace(":UnitedKingdom","")
                    .replace(":Czechia","")
                    .replace(":Iraq","")
                    .replace(":Russia","")
                    .replace(":HongKong","")
                    .replace(":Poland","")
                    .replace(":China","")
                    .replace(":Armenia","")
                    .replace(":Switzerland","")
                    .replace(":Cambodia","")
                    .replace(":T�rkiye","")
                    .replace(":Moldova","")
                    .replace(":Japan","")
                    .replace(":Philippines","")
                    .replace(":Argentina","")
                    .replace(":Malaysia","")
                    .replace(":SouthKorea","")
                    .replace(":Georgia","")
                    .replace(":Hungary","")
                    .replace(":BurkinaFaso","")
                    .replace(":Thailand","")
                    .replace(":Colombia","")
                    .replace(":Bolivia","")
                    .replace(":Austria","")
                    .replace(":Honduras","")
                    .replace(":Mexico","")
                    .replace(":Slovakia","")
                    .replace(":Myanmar","")
                    .replace(":Kosovo","")
                    .replace(":Latvia","")
                    .replace(":Ecuador","")
                    .replace(":Albania","")
                    .replace(":Bosniaand Herzegovina","")
                    .replace(":SouthAfrica","")
                    .replace(":Romania","")
                    .replace(":Chile","")
                    .replace(":Hungary","")
                    .replace(":Panama","")
                    .replace(":Kenya","")
                    .replace(":DRCongo","")
                    .replace(":Venezuela","")
                    .replace(":Peru","")
                    .replace(":Pakistan","")
                    .replace(":Ghana","")
                    .replace(":Uruguay","")
                    .replace(":Nepal","")
                    .replace(":Paraguay","")
                    .replace(":CostaRica","")
                    .replace(":Kazakhstan","")
                    .replace(":Tanzania","")
                    .replace(":Somalia","")
                    .replace(":Iran","")
                    .replace(":Italy","")
                    .replace(":Syria","")
                    .replace(":Kazakhstan","")
                + "\n", "utf8");
            }

            console.log(`Success Gets In ${url}`);
        } else {
            console.log(`Failed In ${url}`);
        }
    } catch (error) {
        console.error(`Something Broken in ${url}`);
    }
};

(async () => {
    for (let url of proxyUrls) {
        await downloadAndSaveProxies(url, outputFile);
    }

    const fileContent = fs.readFileSync(outputFile, "utf8");
    const lines = fileContent.split("\n");
    const uniqueProxies = [...new Set(lines)].join("\n");
    
    fs.writeFileSync(outputFile, uniqueProxies);
    console.log("Successfully cleaned and saved proxies.");
})();
