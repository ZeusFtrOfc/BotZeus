let handler = async m => m.reply(`
╭─「 Donasi • Pulsa 」
│ • Telkomsel [081293537724]
╰────

╭─「 Donasi • Non Pulsa 」
│ • Dana [081393537724]
╰────
`.trim()) // Tambah sendiri kalo mau
handler.help = ['donasi']
handler.tags = ['info']
handler.command = /^dona(te|si)$/i

module.exports = handler
