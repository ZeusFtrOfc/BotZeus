let handler = async (m) => {
    let who
    if (m.isGroup) who = m.mentionedJid[0] ? m.mentionedJid[0] : m.sender
    else who = m.sender
    m.reply(`Limit kamu tersisa : *${global.db.data.users[who].limit}*\nKamu bisa menjadi premium member dalam 1 bulan,silahkan hubungi owner bot!`)
}
handler.help = ['limit [@user]']
handler.tags = ['xp']
handler.command = /^(limit)$/i
module.exports = handler