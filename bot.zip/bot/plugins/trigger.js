//kok cewe gw jadi cuek yahh? daritadi pagi gw chat ga dibales cuman di read doang

const { sticker } = require('../lib/sticker')
const { MessageType } = require('@adiwajshing/baileys')
let handler = async (m, { conn }) => {
  let img = await q.download()
      if (!img) throw `balas gambar dengan caption *${usedPrefix + command}*`
      stiker = await sticker(img, false, global.packname, global.author)
  let marah = global.API('https://some-random-api.ml', '/canvas/triggered', {
  
  })
  let stiker = await sticker(null, marah, global.packname, global.author)
 if (stiker) return conn.sendMessage(m.chat, stiker, MessageType.sticker, {
    quoted: m
  })
  throw stiker.toString()
}


handler.help = ['trigger']
handler.tags = ['maker']

handler.command = /^(trigger)$/i

module.exports = handler
