const path = require('path');

module.exports = {
  stories: [
    '../stories/**/*.mdx',
    '../stories/**/*.stories.@(js|jsx|ts|tsx)'
  ],

  addons: [
    '@storybook/addon-links',
    '@storybook/addon-essentials',
    '@storybook/addon-a11y',
    '@storybook/addon-webpack5-compiler-swc'
  ],

  framework: {
    name: '@storybook/html-webpack5',
    options: {}
  },

  webpackFinal: (config) => {
    // Add support for HTML
    config.module.rules = config.module.rules.map((rule) => {
      if (rule.test && rule.test.toString().includes('\\.html$')) {
        return {
          ...rule,
          use: {
            loader: 'html-loader',
          }
        };
      }
      return rule;
    });

    // Add support for SCSS
    config.module.rules.push({
      test: /\.scss$/,
      use: [
        'style-loader',
        'css-loader',
        {
          loader: 'sass-loader',
          options: {
            sassOptions: {
              // Removes deprecation warnings from Bootstrap
              quietDeps: true,
            }
          }
        }
      ],
      include: path.resolve(__dirname, '../'),
    });

    // Add path aliases
    config.resolve.alias = {
      ...config.resolve.alias,
      '@js': path.resolve(__dirname, '../src/js'),
      '@services': path.resolve(__dirname, '../src/js/services'),
      '@constants': path.resolve(__dirname, '../src/js/constants'),
      '@helpers': path.resolve(__dirname, '../src/js/helpers'),
    };

    // Define external libraries
    config.externals = {
      ...config.externals,
      prestashop: 'prestashop',
    };

    return config;
  },

  docs: {}
};
