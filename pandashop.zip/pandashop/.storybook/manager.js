import { addons } from '@storybook/preview-api';
import psTheme from './ps-theme';

addons.setConfig({
  theme: psTheme,
});
