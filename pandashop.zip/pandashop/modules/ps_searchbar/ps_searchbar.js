/* ps_searchbar.js */
