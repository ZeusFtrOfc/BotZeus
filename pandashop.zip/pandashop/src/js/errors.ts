/**
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

import useToast from '@js/components/useToast';

const initErrorHandler = () => {
  const {Theme: {events}} = window;
  const {prestashop} = window;

  prestashop.on(events.handleError, ({resp}: {resp: {errors?: string[]}}) => {
    if (resp.errors && Array.isArray(resp.errors)) {
      resp.errors.forEach((error) => {
        useToast(error, {type: 'danger'}).show();
      });
    }
  });
};

export default initErrorHandler;
