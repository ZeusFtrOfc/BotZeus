export interface QuickviewResponse {
  quickview_html: string;
  product: { id: number; id_product_attribute: number };
}
